let validator = {}

validator.validateEmpId = (empId) => {
    /*This method should validate employee Id 
        Employee Id should start with 123 and it should be of min length 6
        If the validation fails, throw an error with message 
        "Invalid Employee Id" with status 406
    */
}

// Export validator as module