/*
    Import required modules
    Establish connection to EmployeeDB database in mongodb database using mongoose
    add timestamp to each document
    All employee details should be there in Employee collection
    configure mongoose
 */

/*
create schema for the following structure of document
let empData = {
        empName : "sam",
        empNo : 123456,
        location : "Pune",
        joinedDate : "2017-10-03",
        stream : "UI",
        technology : ["AngularJS","Express","Node"]
    }
*/

/*
   The following validations should be added to each property:
       - All properties are required
       - empNo should be unique
       - technology should be an array and if no technologies 
         are specified by default it should add []
       - If joining date is not specified it should take today's date
*/

let connection = {}

connection.getCollection = () => {
    //establish connection and return model as promise
}

//export the connection object as module