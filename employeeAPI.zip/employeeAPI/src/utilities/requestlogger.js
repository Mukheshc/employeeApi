/*
    Import required module,
    create a request logger which should log all the incoming request in RequestLogger.txt
    It should log time ,type and url of all request
    Export request logger as module
*/

let requestLogger = () => {

}