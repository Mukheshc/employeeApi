/*
    Import all required modules
    Configure the middlewares in correct order
    express server which should listen at port 2050
    export app as module
*/
const express = require("express")
const app = express()