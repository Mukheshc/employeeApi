/*
    Import required modules
*/


user = {}

user.setupDB = () => {
    /*
        - Invoke setupDB method of model/user.js, it returns number of document inserted
        - If documents are inserted return the same
        - Else, throw an error with a message "Insertion Failed", with status 500
    */
}

user.insertEmp = () => {
    /*
        - Invoke validateEmpId of utilities/validator.js by passing empId as parameter
        - Invoke insertEmp method of model/user.js by passing employee object
        - On successfull insertion it returns true, return the same
        - Else throw an error with message "Employee details not added" with  status 400 
    */
}

user.updateSkills = (empId, skills) => {
    /*
        - Invoke updateSkills method of model/user.js by passing skills as parameter
        - On successfull updation it returns the updated skill return the same
        - Else throw an error with a message "Updation of skill set failed" with the status 400
    */
}

user.deleteEmp = (empId) => {
    /*
        - Invoke validateEmpId of utilities/validator.js by passing empId as parameter
        - Invoke deleteEmp method of model/user.js by passing empId as parameter
        - On successfull deletion it returns the empId, return the same
        - Else throw an error with a message "Unable to remove "+<<empId>>+" details"
    */
}

//export user object as module